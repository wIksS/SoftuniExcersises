﻿namespace EstateAgency
{
    public class RealEstate
    {       
    }
}
