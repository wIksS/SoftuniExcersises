﻿namespace EstateAgency
{
    public class EstateAgency
    {
    }
}
