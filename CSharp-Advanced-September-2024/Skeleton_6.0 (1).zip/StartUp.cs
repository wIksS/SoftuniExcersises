﻿namespace SetCover
{
    using System.Collections.Generic;
    class StartUp
    {
        static void Main(string[] args)
        {
          
        }

        public static List<int[]> ChooseSets(IList<int[]> sets, IList<int> universe)
        {
            return null;
        }
    }
}
