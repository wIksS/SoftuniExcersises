﻿namespace FootballManager.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
