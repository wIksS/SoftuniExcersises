﻿namespace P02.Graphic_Editor
{
    public class Rectangle : IShape
    {

    }
}
