﻿namespace P02.Graphic_Editor
{
    public class Circle : IShape
    {
    }
}
