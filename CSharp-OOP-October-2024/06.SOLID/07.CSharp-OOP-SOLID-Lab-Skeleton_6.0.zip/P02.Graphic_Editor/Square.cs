﻿namespace P02.Graphic_Editor
{
    public class Square : IShape
    {
    }
}
