﻿namespace NewsFeed
{
    public class Article
    {
    }
}
