﻿namespace _01.Loader.Models
{
    public enum BaseEntityStatus
    {
        InStore, // 0
        Reserved, // 1
        PendingFunds,// 2
        Payed,// 3
        Sold// 4
    }
}
