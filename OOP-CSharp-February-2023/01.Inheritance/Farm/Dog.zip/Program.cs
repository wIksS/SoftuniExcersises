﻿namespace Farm
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Puppy dog = new Puppy();
            dog.Eat();
            dog.Bark();
            dog.Weep();

            Dog sharo = new Dog();

        }
    }
}