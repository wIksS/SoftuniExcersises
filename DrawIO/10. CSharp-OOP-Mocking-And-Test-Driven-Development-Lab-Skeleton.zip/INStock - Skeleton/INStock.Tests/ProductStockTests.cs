﻿namespace INStock.Tests
{
    using NUnit.Framework;

    public class ProductStockTests
    {
    }
}
