﻿namespace INStock.Tests
{
    public class ProductStockTests
    {
    }
}
