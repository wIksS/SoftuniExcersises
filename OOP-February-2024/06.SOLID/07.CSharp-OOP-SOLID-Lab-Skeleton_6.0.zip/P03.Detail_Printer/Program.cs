﻿namespace P03.DetailPrinter
{
    class Program
    {
        static void Main()
        {
        }
    }
}
