﻿namespace MailClient
{
    public class Mail
    {
    }
}
