﻿namespace MailClient
{
    public class MailBox
    {
    }
}
