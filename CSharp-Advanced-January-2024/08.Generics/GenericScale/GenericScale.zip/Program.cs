﻿

using GenericScale;

EqualityScale<int> scale = new EqualityScale<int>(6,6);

Console.WriteLine(scale.AreEqual());