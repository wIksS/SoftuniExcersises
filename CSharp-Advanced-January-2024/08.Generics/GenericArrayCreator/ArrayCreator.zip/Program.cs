﻿

using GenericArrayCreator;

Console.WriteLine(String.Join(",",ArrayCreator.Create(50, "Fifty")));